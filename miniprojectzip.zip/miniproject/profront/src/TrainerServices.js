import axios from 'axios'

const TRAINER_API_BASE_URL = "http://localhost:8081/api/Trainers";

class TrainerServices {
    getTrainers(){
        return axios.get(TRAINER_API_BASE_URL);
    }
}

export default new TrainerServices();
