import React from 'react';
//import logo from './logo.svg';
import './App.css';
import ListTrainerComponent from './ListTrainerComponent';

function App() {
  return (
    <ListTrainerComponent />
  );
}

export default App;
