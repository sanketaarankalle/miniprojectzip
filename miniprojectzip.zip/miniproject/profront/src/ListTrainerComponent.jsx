import React, { Component } from 'react';
import TrainerServices from './TrainerServices';
    
class ListTrainerComponent extends Component {
    constructor() {
        super();
        this.state= {
            trainers :[]
        }
    }
        componentDidMount(){
            TrainerServices.getTrainers().then((res)=>
            {
                this.setState({trainers: res.data});
            }
            );
        }
    render() {
        return (
            <div>
                <h2 className="text-center"> Trainers List</h2>
                <div ClassName="row">
                    <table className="table table-striped table-bordered">
                        <tbody>
                            <tr>
                                <th>Name </th>   
                                <th>Subject </th>   
                                <th>Email Id</th>    
                            </tr>           
                        </tbody>
                        <tbody>
                            {
                            
                                this.state.trainers.map(
                              
                                    trainers=>
                                <tr key={trainers.id}>
                                    <td> {trainers.fname}</td>
                                    <td> {trainers.subject}</td>
                                    <td> {trainers.email}</td>
                                </tr>
                                )
    }
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }
}

    
export default ListTrainerComponent;


